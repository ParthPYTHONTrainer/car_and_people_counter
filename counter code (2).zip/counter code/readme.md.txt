download objdet and yolo weights and 
put in folder name objdet and yolo weights in base folder


ppt.pt file dowlod and put in projct 3 folder

playingCard.pt file dowlod and put in projct 4 folder